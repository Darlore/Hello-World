# csci41-week3-model3-starter
Starter Code for Week 3 Model 3
These are the files we used in Model 2 of week 3 Class Activity. Download them. You are to fork this repository and modify the SimpleVectorDemo.cpp file as follows:
Create a NEW SimpleVector of ints in addition to the one created in line 12. Update the comment in line 11 accordingly to indicate you are adding two SimpleVectors.
Name the new SimpleVector intTable2 (same size). 
Add a line in the for-loop where the values are stored in the SimpleVectors where count is multiplied by 3 (instead of 2) for the values in intTable2.
Add code to display the values in intTable2 following the lines that display the intTable values. Don't worry about using intTable2 values for anything else (adding 5, etc.)

Create a pull request for your changes to your updated SimpleVectorDemo.cpp file to be merged.
